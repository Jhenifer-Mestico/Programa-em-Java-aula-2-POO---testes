package aula02;

public class Pessoa {
    
    private String nome;
    private int idade;  // criar atributos
    private float altura;
    
    //método construtor
    public Pessoa(String nome, int idade, float altura){
        
        this.nome = nome;
        this.idade = idade;
        this.altura = altura;
    }
    
    public Pessoa (String nome, int idade){
        this.nome = nome;
        this.idade = idade;
    }
    
    public Pessoa(){
        
    }
    
    public void imprimirNome(){
        System.out.println(nome);
    }
    
    public float calculoIMC(float altura, float peso){
        float imc = 0.0f;
        imc = peso / altura*altura;
        
        return imc;
    }
    
    public static void main(String[] args) {
        Pessoa objPessoa = new Pessoa("Jhenifer", 17, 1.65f);
        Pessoa objPessoa1 = new Pessoa("Ana", 22, 1.23f);
        Pessoa objPessoa2 = new Pessoa();
        
        objPessoa.imprimirNome();
        objPessoa.calculoIMC(1.65f, 56);
        
        System.out.println("O IMC é: " + objPessoa.calculoIMC (1.65f, 70));
        
        System.out.println("Nome: " + objPessoa.nome);
        System.out.println("Idade: " + objPessoa.idade);
        System.out.println("Altura: " + objPessoa.altura);
        
        System.out.println("Dados do objeto 1: \n");
        
        System.out.println("Nome: " + objPessoa1.nome);
        System.out.println("dade: " + objPessoa1.idade);
        System.out.println("Altura: " + objPessoa1.altura);
        
        System.out.println("\n Dadosdo objeto 2: \n");
        System.out.println("Nome: " + objPessoa2.nome);
        System.out.println("Idade: " + objPessoa2.idade);
        System.out.println("Altura: " + objPessoa2.altura);
    }
}


    
    /*public Pessoa(){
        nome = JOptionPane.showInputDialog(null,"Insira o nome:", "Nome", JOptionPane.INFORMATION_MESSAGE);
        idade = Integer.parseInt(JOptionPane.showInputDialog(null,"Insira a Idade:", "Idade", JOptionPane.INFORMATION_MESSAGE));
        altura  = Float.parseFloat(JOptionPane.showInputDialog(null,"Insira a altura:", "altura", JOptionPane.INFORMATION_MESSAGE));
    }

testes...
    
    public void imprimirDados(){
        System.out.println(" O nome é: " +nome);
        System.out.println("A idade é:" +  nome);
        System.out.println("A altura é: " + nome);
    }
    
    public float calculoIMC(float altura, float peso){
        float imc = 0.0f;
        imc = peso / altura*altura;
        
        return imc;
    }
    
    /*public static void main(String[] args) {
        
    }
}*/
